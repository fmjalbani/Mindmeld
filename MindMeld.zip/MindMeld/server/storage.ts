import { type WarrantyCheck, type InsertWarrantyCheck } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getWarrantyChecks(): Promise<WarrantyCheck[]>;
  getWarrantyCheckById(id: string): Promise<WarrantyCheck | undefined>;
  createWarrantyCheck(check: InsertWarrantyCheck): Promise<WarrantyCheck>;
}

export class MemStorage implements IStorage {
  private warrantyChecks: Map<string, WarrantyCheck>;

  constructor() {
    this.warrantyChecks = new Map();
  }

  async getWarrantyChecks(): Promise<WarrantyCheck[]> {
    return Array.from(this.warrantyChecks.values());
  }

  async getWarrantyCheckById(id: string): Promise<WarrantyCheck | undefined> {
    return this.warrantyChecks.get(id);
  }

  async createWarrantyCheck(insertCheck: InsertWarrantyCheck): Promise<WarrantyCheck> {
    const id = randomUUID();
    const check: WarrantyCheck = { 
      id,
      brand: insertCheck.brand,
      serialNumber: insertCheck.serialNumber || null,
      model: insertCheck.model || null,
      checkedAt: new Date()
    };
    this.warrantyChecks.set(id, check);
    return check;
  }
}

export const storage = new MemStorage();
