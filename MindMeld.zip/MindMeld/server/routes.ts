import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWarrantyCheckSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Warranty check routes
  app.get("/api/warranty-checks", async (req, res) => {
    try {
      const checks = await storage.getWarrantyChecks();
      res.json(checks);
    } catch (error) {
      res.status(500).json({ error: "Failed to get warranty checks" });
    }
  });

  app.post("/api/warranty-checks", async (req, res) => {
    try {
      const parsed = insertWarrantyCheckSchema.parse(req.body);
      const check = await storage.createWarrantyCheck(parsed);
      res.status(201).json(check);
    } catch (error) {
      res.status(400).json({ error: "Invalid warranty check data" });
    }
  });

  app.get("/api/warranty-checks/:id", async (req, res) => {
    try {
      const check = await storage.getWarrantyCheckById(req.params.id);
      if (!check) {
        return res.status(404).json({ error: "Warranty check not found" });
      }
      res.json(check);
    } catch (error) {
      res.status(500).json({ error: "Failed to get warranty check" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
