import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Initialize AdMob ads after DOM is loaded
const initializeAds = () => {
  if (typeof window !== 'undefined' && window.adsbygoogle) {
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.error('AdMob initialization error:', e);
    }
  }
};

// Initialize ads when app loads
setTimeout(initializeAds, 1000);

createRoot(document.getElementById("root")!).render(<App />);
