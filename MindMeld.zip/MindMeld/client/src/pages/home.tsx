import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Smartphone } from "lucide-react";

const brands = [
  {
    id: "oppo",
    name: "Oppo",
    icon: Smartphone,
    color: "bg-green-600 hover:bg-green-700",
    description: "Check warranty for Oppo smartphones and devices"
  },
  {
    id: "vivo",
    name: "Vivo",
    icon: Smartphone,
    color: "bg-blue-600 hover:bg-blue-700",
    description: "Check warranty for Vivo phones using IMEI"
  },
  {
    id: "sparx",
    name: "Sparx",
    icon: Smartphone,
    color: "bg-purple-600 hover:bg-purple-700",
    description: "Check warranty for Sparx mobile devices"
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Mobile Warranty Check
            </h1>
            <p className="text-muted-foreground mb-1">
              Check your device warranty status quickly and easily
            </p>
            <p className="text-sm text-primary font-medium">
              Created by FM Jalbani Mobile Shop
            </p>
          </div>
        </div>
      </header>

      {/* AdMob Banner */}
      <div className="bg-gray-50 dark:bg-gray-800 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm text-center">
            <ins
              className="adsbygoogle"
              style={{ display: 'block' }}
              data-ad-client="ca-app-pub-9681419108685485"
              data-ad-slot="6683047516"
              data-ad-format="auto"
              data-full-width-responsive="true"
            />
          </div>
        </div>
      </div>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-3">
          {brands.map((brand) => (
            <Card key={brand.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                  <brand.icon className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl">{brand.name}</CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <p className="text-sm text-muted-foreground">
                  {brand.description}
                </p>
                <Link href={`/warranty/${brand.id}`}>
                  <Button 
                    className={`w-full ${brand.color} text-white`}
                    size="lg"
                  >
                    Check {brand.name} Warranty
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Footer AdMob Banner */}
        <div className="mt-12 text-center">
          <div className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-sm">
            <ins
              className="adsbygoogle"
              style={{ display: 'block' }}
              data-ad-client="ca-app-pub-9681419108685485"
              data-ad-slot="6683047516"
              data-ad-format="auto"
              data-full-width-responsive="true"
            />
          </div>
        </div>
      </main>
    </div>
  );
}
