import { useParams } from "wouter";
import { useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

// Show interstitial ad on page load
const showInterstitialAd = () => {
  if (typeof window !== 'undefined' && window.adsbygoogle) {
    try {
      // Create interstitial ad element
      const adContainer = document.createElement('div');
      adContainer.innerHTML = `
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-app-pub-9681419108685485"
             data-ad-slot="8032406753"
             data-ad-format="interstitial"
             data-full-width-responsive="true">
        </ins>
      `;
      document.body.appendChild(adContainer);
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.error('Interstitial Ad error:', e);
    }
  }
};

const brandUrls = {
  oppo: "https://support.oppo.com/pk/warranty-check/",
  vivo: "https://www.vivo.com/pk/support/IMEI",
  sparx: "https://deploy.com.pk/warranty-check/"
};

const brandNames = {
  oppo: "Oppo",
  vivo: "Vivo", 
  sparx: "Sparx"
};

export default function WebviewPage() {
  const params = useParams();
  const brand = params.brand as keyof typeof brandUrls;
  const [isLoading, setIsLoading] = useState(true);
  
  useEffect(() => {
    // Show interstitial ad when page loads
    const adTimer = setTimeout(showInterstitialAd, 500);
    
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);
    
    return () => {
      clearTimeout(timer);
      clearTimeout(adTimer);
    };
  }, []);

  if (!brand || !brandUrls[brand]) {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">Brand not found</h1>
            <Link href="/">
              <Button>Go Back</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="webview-container bg-background flex flex-col overflow-hidden no-zoom">
      {/* Compact Header */}
      <div className="bg-white dark:bg-gray-900 border-b border-border p-2 flex items-center gap-3 flex-shrink-0 h-12">
        <Link href="/">
          <Button variant="ghost" size="sm" className="p-2 h-8 w-8">
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </Link>
        <div className="flex-1">
          <h1 className="text-sm font-semibold truncate">{brandNames[brand]} Warranty</h1>
          <p className="text-xs text-muted-foreground">FM Jalbani Mobile Shop</p>
        </div>
      </div>

      {/* Compact AdMob Banner */}
      <div className="bg-gray-50 dark:bg-gray-800 p-1 flex-shrink-0">
        <div className="bg-white dark:bg-gray-700 rounded p-1">
          <ins
            className="adsbygoogle"
            style={{ display: 'block', height: '50px', minHeight: '50px' }}
            data-ad-client="ca-app-pub-9681419108685485"
            data-ad-slot="6683047516"
            data-ad-format="banner"
            data-full-width-responsive="true"
          />
        </div>
      </div>

      {/* Full Screen Webview */}
      <div className="flex-1 relative overflow-hidden" style={{ height: 'calc(100vh - 120px)' }}>
        {isLoading && (
          <div className="absolute inset-0 bg-white dark:bg-gray-900 flex items-center justify-center z-10">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-sm text-muted-foreground">Loading warranty service...</p>
            </div>
          </div>
        )}
        <iframe
          src={brandUrls[brand]}
          className="webview-iframe w-full h-full border-0"
          title={`${brandNames[brand]} Warranty Check`}
          onLoad={() => setIsLoading(false)}
          allow="camera; microphone; geolocation; clipboard-read; clipboard-write"
          sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-top-navigation allow-downloads"
          style={{ width: '100%', height: '100%' }}
        />
      </div>
    </div>
  );
}