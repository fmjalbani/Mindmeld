import { useEffect, useRef } from 'react';

interface AdMobBannerProps {
  adUnitId: string;
  className?: string;
}

export function AdMobBanner({ adUnitId, className = "" }: AdMobBannerProps) {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check if AdMob is available (window.adsbygoogle)
    if (typeof window !== 'undefined' && window.adsbygoogle) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {
        console.error('AdMob error:', e);
      }
    }
  }, []);

  return (
    <div className={`admob-banner ${className}`} ref={adRef}>
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-app-pub-9681419108685485"
        data-ad-slot={adUnitId.split('/')[1]}
        data-ad-format="auto"
        data-full-width-responsive="true"
      />
    </div>
  );
}

// Interstitial Ad component
export function AdMobInterstitial({ adUnitId }: { adUnitId: string }) {
  const showInterstitial = () => {
    if (typeof window !== 'undefined' && window.adsbygoogle) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (e) {
        console.error('AdMob Interstitial error:', e);
      }
    }
  };

  useEffect(() => {
    // Auto-show interstitial after component mounts
    const timer = setTimeout(showInterstitial, 1000);
    return () => clearTimeout(timer);
  }, []);

  return null; // Interstitials don't render visible elements
}

// Add global type declaration
declare global {
  interface Window {
    adsbygoogle: any[];
  }
}