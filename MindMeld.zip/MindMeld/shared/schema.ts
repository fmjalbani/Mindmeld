import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const warrantyChecks = pgTable("warranty_checks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  brand: text("brand").notNull(),
  serialNumber: text("serial_number"),
  model: text("model"),
  checkedAt: timestamp("checked_at").defaultNow().notNull(),
});

export const insertWarrantyCheckSchema = createInsertSchema(warrantyChecks).pick({
  brand: true,
  serialNumber: true,
  model: true,
});

export type InsertWarrantyCheck = z.infer<typeof insertWarrantyCheckSchema>;
export type WarrantyCheck = typeof warrantyChecks.$inferSelect;
